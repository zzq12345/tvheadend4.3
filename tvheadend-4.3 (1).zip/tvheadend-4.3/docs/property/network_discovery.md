:

Option                         | Description
-------------------------------|------------
**Disable**                    | Disable mux discovery.
**New muxes only**             | Discover new muxes only.
**New muxes + changed muxes**  | Discover new muxes and changes to existing muxes.
