:

Option                   | Description
-------------------------|------------
**Default**              | Use the "Persistent user interface level" value as set in [Base Config](class/config).
**No**                   | Prevent the user from changing their view level and hide the view level drop-dowm from the interface.
**Yes**                  | Allow the user to change the interface view level.
