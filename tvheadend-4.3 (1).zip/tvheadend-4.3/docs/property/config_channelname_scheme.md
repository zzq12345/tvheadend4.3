: 

The *Channel icon path* (above) must be set to generate the filenames. 
Also note that changing the scheme will not update existing icons, you must 
use the *[Reset Icons]* button in the [Channels](class/channel) tab
to re-generate them.

Scheme                 | Description
-----------------------|-------------------
No scheme              | Use service name "as is" to generate the filename.
All lower-case         | Generate lower-case filenames.
Service name picons    | Generate lower-case filenames using picon formatting.
