:

Option                  | Description
------------------------|------------
**Basic**               | Show basic settings/information.
**Advanced**            | Show more advanced settings/information.
**Expert**              | Show the expert (All) settings/information.

This setting can be overridden on a per-user basis, see [Access Entries](class/access).
