:

Option                         | Description
-------------------------------|------------
**Create bouquet tag**         | Create a tag with the bouquets name and link it to all channels created by the bouquet.
**Create type-based tags**     | Create a tag based on the channel type and link it to the channel.
**Create provider name tags**  | Create a tag with the channel provider's name and link it to the channel.
**Create network name tags**   | Create a tag with the network name and link it to all channels created by the bouquet.
