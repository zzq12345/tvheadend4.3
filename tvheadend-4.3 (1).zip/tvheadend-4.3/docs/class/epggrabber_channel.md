This tab displays EPG data used by channels.

!['EPG Grabber Channels Tab'](static/img/doc/epggrabber_channel/tab.png)

---

###Menu Bar/Buttons

The following functions are available:

Button                      | Function
----------------------------|-------------------
**Save**                    | Save any changes made to the grid.
**Undo**                    | Revert any changes made since the last save.
**Delete**                  | Delete the selected grid entries.
**Edit**                    | Edit the selected grid entries.

---
