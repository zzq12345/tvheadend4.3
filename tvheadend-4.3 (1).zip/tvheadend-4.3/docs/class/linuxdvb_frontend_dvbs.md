This panel lists all the available satellite (DVB-S/ISDB-S) frontend 
parameters.

!['DVB-S frontend parameters'](static/img/doc/linuxdvb_frontend_dvbs/tab.png)

---

###Buttons

The following buttons are available:

Button         | Function
---------------|---------
**Save**       | Save the current configuration.
<tvh_include>inc/common_button_table_end</tvh_include>

---
