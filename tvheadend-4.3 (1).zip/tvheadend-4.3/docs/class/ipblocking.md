This tab allows to configure blocked IP ranges. Users within these ranges
are not allowed to login (use any Tvheadend service).

!['Access Control - Entries tab'](static/img/doc/ipblocking/tab.png)

---

<tvh_include>inc/common_button_table_start</tvh_include>

<tvh_include>inc/common_button_table_end</tvh_include>

---
