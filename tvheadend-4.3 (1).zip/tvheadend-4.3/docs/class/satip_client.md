This panel displays all available SAT>IP client parameters.

!['SAT>IP Panel'](static/img/doc/satip_client/tab.png)

---

###Buttons

The following buttons are available:

Button         | Function
---------------|---------
**Save**       | Save the current configuration.
<tvh_include>inc/common_button_table_end</tvh_include>

---
