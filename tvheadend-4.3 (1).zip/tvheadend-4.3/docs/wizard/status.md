Tvheadend is now scanning for available services. Please wait until the
scan completes..


**Notes**:


* During scanning, the number of muxes and services shown below should
  increase. If this doesn't happen, check the connection(s) to your
  device(s)..
* The status tab (behind this wizard) will display signal information.
  If you notice a lot of errors or the signal strength appears low then
  this usually indicates a physical issue with your antenna, satellite
  dish or cable..
* If you don't see any signal information at all, but the number of
  muxes or services is increasing anyway, the driver used by your device
  isn't supplying signal information to Tvheadend. In most cases this
  isn't an issue..
