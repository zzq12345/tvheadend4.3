###Menu Bar/Buttons

The following functions are available:

Button                 | Function
-----------------------|-------------------
**Save**               | Save any changes made to the grid/entries.
**Undo**               | Revert any changes made since the last save.
**Add**                | Display the *Add entry* dialog.
**Delete**             | Delete the selected entry/entries.
**Edit**               | Edit the selected entries.
