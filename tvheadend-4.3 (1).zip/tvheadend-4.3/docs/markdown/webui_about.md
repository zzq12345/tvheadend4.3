##About

This page displays general information about the current Tvheadend 
version.

The build arguments/options used during compilation can be seen by 
clicking the _Toggle details_ link (only visible to users with admin 
rights). 
