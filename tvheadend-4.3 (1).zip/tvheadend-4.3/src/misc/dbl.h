#pragma once

double my_str2double(const char *str, const char **endp);

int my_double2str(char *buf, size_t bufsize, double realvalue);
