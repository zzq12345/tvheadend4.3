AUTOBUILD_CONFIGURE_EXTRA="${AUTOBUILD_CONFIGURE_EXTRA:-} --arch=arm64"
DEBDIST=xenial
source Autobuild/debian.sh
