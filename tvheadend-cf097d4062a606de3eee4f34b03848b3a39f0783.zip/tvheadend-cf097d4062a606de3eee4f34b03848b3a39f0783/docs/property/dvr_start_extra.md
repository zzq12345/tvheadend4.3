:
 
For example, if a program is to start at 13:00 and you set a padding of 
5 minutes, it will start recording at 12:54:30 (including a warm-up 
time of 30 seconds (user configurable)). Setting the padding per 
channel will override the padding set in the [DVR Profile](class/profile). 

Be sure to check you have enough free tuners available
to record all scheduled recordings if they overlap.
