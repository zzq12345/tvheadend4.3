:
 
This is extremely useful for those programs you think/know will overrun. 
Any value selected here will keep a tuner busy for longer, so be sure 
to check you have enough free tuners to record all scheduled recordings 
if they overlap. Setting the padding per 
channel will override the padding set in the [DVR Profile](class/profile).
