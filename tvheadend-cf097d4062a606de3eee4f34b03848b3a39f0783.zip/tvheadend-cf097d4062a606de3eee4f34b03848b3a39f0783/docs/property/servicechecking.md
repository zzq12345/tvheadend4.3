:

Option                        | Description
------------------------------|------------
**Auto check enabled**        | Enable automatic service checking.
**Auto check disabled**       | Disable automatic service checking.
**Missing In PAT/SDT**        | The service is no longer available on this mux.
