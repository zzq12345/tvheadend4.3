:

String | Format Result
------ | -------------
%F     | The date in ISO-format (e.g. 2015-02-28).
%R     | The time in 24h HH:MM format (e.g. 19:45).
%x     | The date, formatted according to your locale settings.

The escape-codes use the
[strftime](http://man7.org/linux/man-pages/man3/strftime.3.html) format.
