This tab displays various memory usage information useful for debugging.

**It does not have any user configurable options.**
