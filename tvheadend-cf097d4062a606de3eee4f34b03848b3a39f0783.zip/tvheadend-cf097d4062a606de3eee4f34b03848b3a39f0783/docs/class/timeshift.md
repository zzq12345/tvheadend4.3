This tab is used to configure timeshift properties.

!['Timeshift Tab'](static/img/doc/timeshift/tab.png)

---

###Menu Bar/Buttons

The following functions are available:

Button     | Function
-----------|---------
**Save**   | Save the current configuration.
**Undo**   | Revert the changes made since last save.
<tvh_include>inc/common_button_table_end</tvh_include>

---
