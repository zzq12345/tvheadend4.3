Mux Schedulers enable Tvheadend to automatically play channels. This is 
useful to get EPG, services or access rights updates.

!['Mux Schedule Entries'](static/img/doc/mpegts_mux_sched/tab.png)

---
