This panel lists all the available Terrestrial (DVB-T/T2/ISDB-T/ATSC-T) frontend 
parameters.

!['DVB-T frontend parameters'](static/img/doc/linuxdvb_frontend_dvbt/tab.png)

---

###Buttons

The following buttons are available:

Button         | Function
---------------|---------
**Save**       | Save the current configuration.
<tvh_include>inc/common_button_table_end</tvh_include>

---
