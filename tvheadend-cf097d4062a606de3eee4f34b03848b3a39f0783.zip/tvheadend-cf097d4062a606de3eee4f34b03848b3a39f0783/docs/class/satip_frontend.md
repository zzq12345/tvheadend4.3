This panel displays all available SAT>IP 
DVB-T/DVB-S/DVB-C/ATSC-T/ATSC-C frontend parameters.

---

###Buttons

The following buttons are available:

Button         | Function
---------------|---------
**Save**       | Save the current configuration.
<tvh_include>inc/common_button_table_end</tvh_include>

---
